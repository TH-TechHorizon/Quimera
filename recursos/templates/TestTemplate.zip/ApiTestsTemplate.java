package teste;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.qameta.allure.Epic;
import io.qameta.allure.Story;
import test.api.extension.TestApiExtension;

@Epic("Template de Teste de API")
public class ApiTestsTemplate extends TestApiExtension {

	/*	URL da API a ser Testada */
	String URLAPIs = getUrlAPIDefault() + "Link da API após o res/";


	/*	Variáveis do Corpo do JSON
		Exemplo:

		listDadosGeraisNotaFiscal bodyData = new listDadosGeraisNotaFiscal();
		listDadosGeraisNotaFiscal.filtro filtro = new listDadosGeraisNotaFiscal.filtro();
		listDadosGeraisNotaFiscal.empresa empresa = new listDadosGeraisNotaFiscal.empresa();
		pageRequest pageRequest = new pageRequest();
		orderBy orderBy = new orderBy();
		List<orderBy> orders = new ArrayList<orderBy>();

	 **/


	/*	Reset das variáveis! */
	@BeforeTest
	public void recarregarVariaveisDeTeste() {
		/*	Exemplo:

			bodyData = new listDadosGeraisNotaFiscal();
			filtro = new listDadosGeraisNotaFiscal.filtro();
			empresa = new listDadosGeraisNotaFiscal.empresa();
			pageRequest = new pageRequest();
			orderBy = new orderBy();
			orderBy.setField("e070fil.codfil");

		 **/
	}


	/* Chamada da API 
	 	Função da chamada da API como exemplo:
 
		public Response ListDadosGeraisNotaFiscal(ListDadosGeraisNotaFiscal bodyData) {
			Response resultData = Request.POST.enviar(authorizationBearer, null, bodyData, URLAPIs);
			return resultData;
		}

	 **/



	/*	[Cenários De Testes] */

		@Test(	description = "Descrição Genérica do Teste", 
				suiteName = "Nome da Suite" /*Nome da Suite de Teste (Se possuir), caso não possua, pode usar o nome da classe*/ 
		)
		@Story("Template de Teste (Pode ser o mesmo nome da Descrição)")
		public void test000() throws JsonProcessingException {
			/*
			orders.add(orderBy);
			filtro.setEmpresa(empresa);
			pageRequest.setOffset(0);
			pageRequest.setSize(10);
			pageRequest.setOrderBy(orders);
			bodyData.setFiltro(filtro);
			bodyData.setPageRequest(pageRequest);
			Response respost = listDadosGeraisNotaFiscal(bodyData);
			Valida.statusIgual(respost, 200);
			Valida.seJson.tem.tamanhoIgual(respost, 10, "itens");
			Valida.seJson.naoTem.textoNulo(respost, "totalElements");
			*/
		}

}
