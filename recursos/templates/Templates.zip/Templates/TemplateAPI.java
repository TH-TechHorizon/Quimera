package SeuPacoteDeTestes;

import java.sql.SQLException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.qameta.allure.Epic;
import io.qameta.allure.Story;
import quimera.test.extension.api.TestExtension;
import quimera.test.utilities.DataBaseUtilities.Select;
import quimera.test.utilities.DataBaseUtilities.Update;
import quimera.test.utilities.assertion.AssertThat;

@Epic("Tela de Login")
public class ApiTestsTemplate extends TestExtension {
	
	/*	URL da API a ser Testada */
	/*String URLAPIs = getUrlAPIDefault() + "create"; // Usar o getUrlAPIDefault() para buscar os dados do Json de configuração. */
	String URLAPIs = "http://dummy.restapiexample.com/api/v1/create";
	
	/*	Variáveis do Corpo do JSON	*/
	createData bodyData = new createData();

	@BeforeTest /*Se precisar crie um @BeforeTest para configurar os testes. */
	public void recarregarVariaveisDeTeste() {
		bodyData = new createData();
	}
	
	/* Chamada da API  */
	public Response createEmployee(createData bodyData) {
		Response resultData = TestRequest.request(HttpMethod.POST, false, bodyData, URLAPIs)
		return resultData;
	}

	/*	[Cenários De Testes] */
	@Test(	description = "Descrição Genérica do Teste", 
			suiteName = "Nome da Suite" /*Nome da Suite de Teste (Se possuir), caso não possua, pode usar o nome da classe*/ 
	)
	@Story("Template de Teste (Pode ser o mesmo nome da Descrição)")
	public void test000() throws JsonProcessingException {
		bodyData.setName("teste");
		bodyData.setSalary(1500);
		bodyData.setAge(25);
		Response respost = createEmployee(bodyData);
		AssertThat.rest()
			.isEqualStatusCode(respost, 200)
			.rest().isEqualSize(respost, 4 ,"data")
			.rest().isEqualText(respost, "success", "status")
		;
	}

}
