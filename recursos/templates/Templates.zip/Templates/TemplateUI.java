package SeuPacoteDeTestes;

import java.sql.SQLException;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.qameta.allure.Epic;
import io.qameta.allure.Story;
import quimera.test.extension.ui.TestExtension;
import quimera.test.utilities.DataBaseUtilities.Select;
import quimera.test.utilities.DataBaseUtilities.Update;
import quimera.test.utilities.assertion.AssertThat;

@Epic("Tela de Login")
public class ApiTestsTemplate extends TestExtension {

	@BeforeTest /*Se precisar crie um @BeforeTest para configurar os testes. */
	public void Setup() {
		Update.generico("insert into usuarios (name) values ('Quimera');");
	}
	
	@Test(	
		description = "Valida digitação do username de usuario", 
		suiteName = "Validação de Campos" /*Nome da Suite de Teste (Se possuir), caso não possua, pode usar o nome da classe*/
	)
	@Story("Login")
	public void test000() throws SQLException {
		String nomeUsuario = Select.textoEmColuna("select * from usuarios;", "name");
		uiTool
			.navegateTo("http://www.juliodelima.com.br//taskit")
			.waitPage(false)
			.waitField(By.linkText("Sign in"), false)
			.click(By.linkText("Sign in"))
			.waitField(By.xpath("//*[@id='signinbox']/div[1]/form/div[2]/div[1]/input"), false)
			.setKeys(nomeUsuario, By.xpath("//*[@id='signinbox']/div[1]/form/div[2]/div[1]/input"))
		;
		AssertThat.ui().isEqualValue(By.xpath("//*[@id='signinbox']/div[1]/form/div[2]/div[1]/input"), nomeUsuario);
	}

}
